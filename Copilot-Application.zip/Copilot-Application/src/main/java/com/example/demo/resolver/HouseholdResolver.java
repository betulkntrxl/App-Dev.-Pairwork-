package com.example.demo.resolver;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.example.demo.entity.Household;
import com.example.demo.service.HouseholdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class HouseholdResolver implements GraphQLQueryResolver, GraphQLMutationResolver {

    @Autowired
    private HouseholdService householdService;

    @PreAuthorize("hasRole('USER')")
    public List<Household> getAllHouseholds() {
        return householdService.getAllHouseholds();
    }

    @PreAuthorize("hasRole('USER')")
    public Household getHouseholdById(Long id) {
        return householdService.getHouseholdById(id);
    }

    @PreAuthorize("hasRole('ADMIN')")
    public Household createHousehold(String address, String eircode) {
        Household household = new Household();
        household.setAddress(address);
        household.setEircode(eircode);
        return householdService.saveHousehold(household);
    }

    @PreAuthorize("hasRole('ADMIN')")
    public Household updateHousehold(Long id, String address, String eircode) {
        Household household = householdService.getHouseholdById(id);
        if (household != null) {
            household.setAddress(address);
            household.setEircode(eircode);
            return householdService.saveHousehold(household);
        }
        return null;
    }

    @PreAuthorize("hasRole('ADMIN')")
    public boolean deleteHousehold(Long id) {
        householdService.deleteHousehold(id);
        return true;
    }
}