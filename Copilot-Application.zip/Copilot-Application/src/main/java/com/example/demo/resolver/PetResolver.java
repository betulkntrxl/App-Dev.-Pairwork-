package com.example.demo.resolver;

import com.coxautodev.graphql.tools.GraphQLQueryResolver;
import com.coxautodev.graphql.tools.GraphQLMutationResolver;
import com.example.demo.entity.Pet;
import com.example.demo.entity.Household;
import com.example.demo.service.PetService;
import com.example.demo.service.HouseholdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PetResolver implements GraphQLQueryResolver, GraphQLMutationResolver {

    @Autowired
    private PetService petService;

    @Autowired
    private HouseholdService householdService;

    @PreAuthorize("hasRole('USER')")
    public List<Pet> getAllPets() {
        return petService.getAllPets();
    }

    @PreAuthorize("hasRole('USER')")
    public Pet getPetById(Long id) {
        return petService.getPetById(id);
    }

    @PreAuthorize("hasRole('ADMIN')")
    public Pet createPet(String name, String type, Long householdId) {
        Pet pet = new Pet();
        pet.setName(name);
        pet.setType(type);
        if (householdId != null) {
            Household household = householdService.getHouseholdById(householdId);
            pet.setHousehold(household);
        }
        return petService.savePet(pet);
    }

    @PreAuthorize("hasRole('ADMIN')")
    public Pet updatePet(Long id, String name, String type, Long householdId) {
        Pet pet = petService.getPetById(id);
        if (pet != null) {
            pet.setName(name);
            pet.setType(type);
            if (householdId != null) {
                Household household = householdService.getHouseholdById(householdId);
                pet.setHousehold(household);
            }
            return petService.savePet(pet);
        }
        return null;
    }

    @PreAuthorize("hasRole('ADMIN')")
    public boolean deletePet(Long id) {
        petService.deletePet(id);
        return true;
    }
}