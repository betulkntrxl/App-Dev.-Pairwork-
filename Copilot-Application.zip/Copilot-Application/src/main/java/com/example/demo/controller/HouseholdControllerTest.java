package com.example.demo.controller;

import com.example.demo.entity.Household;
import com.example.demo.service.HouseholdService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class HouseholdControllerTest {

    private MockMvc mockMvc;

    @Mock
    private HouseholdService householdService;

    @InjectMocks
    private HouseholdController householdController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(householdController).build();
    }

    @Test
    public void testGetAllHouseholds() throws Exception {
        Household household = new Household();
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdService.getAllHouseholds()).thenReturn(Arrays.asList(household));

        mockMvc.perform(get("/households"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].address").value("123 Main St"));
    }

    @Test
    public void testGetHouseholdById() throws Exception {
        Household household = new Household();
        household.setId(1L);
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdService.getHouseholdById(1L)).thenReturn(household);

        mockMvc.perform(get("/households/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.address").value("123 Main St"));
    }

    @Test
    public void testCreateHousehold() throws Exception {
        Household household = new Household();
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdService.saveHousehold(any(Household.class))).thenReturn(household);

        mockMvc.perform(post("/households")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"address\":\"123 Main St\",\"eircode\":\"A1B2C3D\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.address").value("123 Main St"));
    }

    @Test
    public void testUpdateHousehold() throws Exception {
        Household household = new Household();
        household.setId(1L);
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdService.saveHousehold(any(Household.class))).thenReturn(household);

        mockMvc.perform(put("/households/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"address\":\"123 Main St\",\"eircode\":\"A1B2C3D\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.address").value("123 Main St"));
    }

    @Test
    public void testDeleteHousehold() throws Exception {
        doNothing().when(householdService).deleteHousehold(1L);

        mockMvc.perform(delete("/households/1"))
                .andExpect(status().isOk());
    }
}