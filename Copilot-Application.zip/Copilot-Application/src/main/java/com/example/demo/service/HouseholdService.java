package com.example.demo.service;

import com.example.demo.entity.Household;
import com.example.demo.repository.HouseholdRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HouseholdService {
    @Autowired
    private HouseholdRepository householdRepository;

    public List<Household> getAllHouseholds() {
        return householdRepository.findAll();
    }

    public Household getHouseholdById(Long id) {
        return householdRepository.findById(id).orElse(null);
    }

    public Household saveHousehold(Household household) {
        return householdRepository.save(household);
    }

    public void deleteHousehold(Long id) {
        householdRepository.deleteById(id);
    }
}