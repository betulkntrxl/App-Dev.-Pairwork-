package com.example.demo.repository;

import com.example.demo.entity.Pet;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class PetRepositoryTest {

    @Autowired
    private PetRepository petRepository;

    @Test
    public void testSaveAndFindPet() {
        Pet pet = new Pet();
        pet.setName("Buddy");
        pet.setType("Dog");

        petRepository.save(pet);

        List<Pet> pets = petRepository.findAll();
        assertThat(pets).hasSize(1);
        assertThat(pets.get(0).getName()).isEqualTo("Buddy");
    }
}