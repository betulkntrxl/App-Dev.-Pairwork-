package com.example.demo.service;

import com.example.demo.entity.Pet;
import com.example.demo.repository.PetRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class PetServiceTest {

    @Mock
    private PetRepository petRepository;

    @InjectMocks
    private PetService petService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllPets() {
        Pet pet = new Pet();
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petRepository.findAll()).thenReturn(Arrays.asList(pet));

        List<Pet> pets = petService.getAllPets();
        assertThat(pets).hasSize(1);
        assertThat(pets.get(0).getName()).isEqualTo("Buddy");
    }

    @Test
    public void testGetPetById() {
        Pet pet = new Pet();
        pet.setId(1L);
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petRepository.findById(1L)).thenReturn(Optional.of(pet));

        Pet foundPet = petService.getPetById(1L);
        assertThat(foundPet).isNotNull();
        assertThat(foundPet.getName()).isEqualTo("Buddy");
    }

    @Test
    public void testSavePet() {
        Pet pet = new Pet();
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petRepository.save(pet)).thenReturn(pet);

        Pet savedPet = petService.savePet(pet);
        assertThat(savedPet).isNotNull();
        assertThat(savedPet.getName()).isEqualTo("Buddy");
    }

    @Test
    public void testDeletePet() {
        Pet pet = new Pet();
        pet.setId(1L);
        pet.setName("Buddy");
        pet.setType("Dog");

        doNothing().when(petRepository).deleteById(1L);

        petService.deletePet(1L);
        verify(petRepository, times(1)).deleteById(1L);
    }
}