package com.example.demo.controller;

import com.example.demo.entity.Household;
import com.example.demo.service.HouseholdService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/households")
public class HouseholdController {
    @Autowired
    private HouseholdService householdService;

    @GetMapping
    public List<Household> getAllHouseholds() {
        return householdService.getAllHouseholds();
    }

    @GetMapping("/{id}")
    public Household getHouseholdById(@PathVariable Long id) {
        return householdService.getHouseholdById(id);
    }

    @PostMapping
    public Household createHousehold(@Valid @RequestBody Household household) {
        return householdService.saveHousehold(household);
    }

    @PutMapping("/{id}")
    public Household updateHousehold(@PathVariable Long id, @Valid @RequestBody Household household) {
        household.setId(id);
        return householdService.saveHousehold(household);
    }

    @DeleteMapping("/{id}")
    public void deleteHousehold(@PathVariable Long id) {
        householdService.deleteHousehold(id);
    }
}