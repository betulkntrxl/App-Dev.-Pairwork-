package com.example.demo.service;

import com.example.demo.entity.Household;
import com.example.demo.repository.HouseholdRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class HouseholdServiceTest {

    @Mock
    private HouseholdRepository householdRepository;

    @InjectMocks
    private HouseholdService householdService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllHouseholds() {
        Household household = new Household();
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdRepository.findAll()).thenReturn(Arrays.asList(household));

        List<Household> households = householdService.getAllHouseholds();
        assertThat(households).hasSize(1);
        assertThat(households.get(0).getAddress()).isEqualTo("123 Main St");
    }

    @Test
    public void testGetHouseholdById() {
        Household household = new Household();
        household.setId(1L);
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdRepository.findById(1L)).thenReturn(Optional.of(household));

        Household foundHousehold = householdService.getHouseholdById(1L);
        assertThat(foundHousehold).isNotNull();
        assertThat(foundHousehold.getAddress()).isEqualTo("123 Main St");
    }

    @Test
    public void testSaveHousehold() {
        Household household = new Household();
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        when(householdRepository.save(household)).thenReturn(household);

        Household savedHousehold = householdService.saveHousehold(household);
        assertThat(savedHousehold).isNotNull();
        assertThat(savedHousehold.getAddress()).isEqualTo("123 Main St");
    }

    @Test
    public void testDeleteHousehold() {
        Household household = new Household();
        household.setId(1L);
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        doNothing().when(householdRepository).deleteById(1L);

        householdService.deleteHousehold(1L);
        verify(householdRepository, times(1)).deleteById(1L);
    }
}