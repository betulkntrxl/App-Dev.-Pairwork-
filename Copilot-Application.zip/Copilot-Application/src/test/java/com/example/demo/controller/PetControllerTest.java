package com.example.demo.controller;

import com.example.demo.entity.Pet;
import com.example.demo.service.PetService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Arrays;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class PetControllerTest {

    private MockMvc mockMvc;

    @Mock
    private PetService petService;

    @InjectMocks
    private PetController petController;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(petController).build();
    }

    @Test
    public void testGetAllPets() throws Exception {
        Pet pet = new Pet();
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petService.getAllPets()).thenReturn(Arrays.asList(pet));

        mockMvc.perform(get("/pets"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].name").value("Buddy"));
    }

    @Test
    public void testGetPetById() throws Exception {
        Pet pet = new Pet();
        pet.setId(1L);
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petService.getPetById(1L)).thenReturn(pet);

        mockMvc.perform(get("/pets/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Buddy"));
    }

    @Test
    public void testCreatePet() throws Exception {
        Pet pet = new Pet();
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petService.savePet(any(Pet.class))).thenReturn(pet);

        mockMvc.perform(post("/pets")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Buddy\",\"type\":\"Dog\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Buddy"));
    }

    @Test
    public void testUpdatePet() throws Exception {
        Pet pet = new Pet();
        pet.setId(1L);
        pet.setName("Buddy");
        pet.setType("Dog");

        when(petService.savePet(any(Pet.class))).thenReturn(pet);

        mockMvc.perform(put("/pets/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Buddy\",\"type\":\"Dog\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Buddy"));
    }

    @Test
    public void testDeletePet() throws Exception {
        doNothing().when(petService).deletePet(1L);

        mockMvc.perform(delete("/pets/1"))
                .andExpect(status().isOk());
    }
}