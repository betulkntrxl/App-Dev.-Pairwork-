package com.example.demo.repository;

import com.example.demo.entity.Household;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class HouseholdRepositoryTest {

    @Autowired
    private HouseholdRepository householdRepository;

    @Test
    public void testSaveAndFindHousehold() {
        Household household = new Household();
        household.setAddress("123 Main St");
        household.setEircode("A1B2C3D");

        householdRepository.save(household);

        List<Household> households = householdRepository.findAll();
        assertThat(households).hasSize(1);
        assertThat(households.get(0).getAddress()).isEqualTo("123 Main St");
    }
}