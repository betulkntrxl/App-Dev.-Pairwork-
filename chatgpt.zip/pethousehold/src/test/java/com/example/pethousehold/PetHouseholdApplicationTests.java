package com.example.pethousehold;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetHouseholdApplicationTests {

	@Test
	void contextLoads() {
	}

}
