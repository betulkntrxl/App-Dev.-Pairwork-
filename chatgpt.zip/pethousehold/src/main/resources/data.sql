INSERT INTO household (id, name) VALUES (1, 'Household 1');
INSERT INTO pet (id, name, type, household_id) VALUES (1, 'Buddy', 'Dog', 1);
