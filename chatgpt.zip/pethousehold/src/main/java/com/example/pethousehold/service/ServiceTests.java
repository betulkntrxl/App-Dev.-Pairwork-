// Test for Service Layer
package com.example.pethousehold.service;

import com.example.pethousehold.entity.Household;
import com.example.pethousehold.entity.Pet;
import com.example.pethousehold.repository.HouseholdRepository;
import com.example.pethousehold.repository.PetRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.util.Optional;
import static org.mockito.Mockito.*;
import static org.assertj.core.api.Assertions.assertThat;

public class ServiceTests {

    @Mock
    private HouseholdRepository householdRepository;

    @Mock
    private PetRepository petRepository;

    @InjectMocks
    private HouseholdService householdService;

    @InjectMocks
    private PetService petService;

    public ServiceTests() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetHouseholdById() {
        Household household = new Household();
        household.setId(1L);
        when(householdRepository.findById(1L)).thenReturn(Optional.of(household));

        Optional<Household> result = householdService.getHouseholdById(1L);
        assertThat(result).isPresent();
        verify(householdRepository, times(1)).findById(1L);
    }

    @Test
    public void testCreatePet() {
        Pet pet = new Pet();
        pet.setName("New Pet");
        when(petRepository.save(pet)).thenReturn(pet);

        Pet result = petService.createPet(pet);
        assertThat(result.getName()).isEqualTo("New Pet");
        verify(petRepository, times(1)).save(pet);
    }
}
