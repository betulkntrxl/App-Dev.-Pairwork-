// REST Controller
package com.example.pethousehold.controller;

import com.example.pethousehold.entity.Household;
import com.example.pethousehold.entity.Pet;
import com.example.pethousehold.service.HouseholdService;
import com.example.pethousehold.service.PetService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
public class PetHouseholdController {

    private final HouseholdService householdService;
    private final PetService petService;

    public PetHouseholdController(HouseholdService householdService, PetService petService) {
        this.householdService = householdService;
        this.petService = petService;
    }

    @GetMapping("/households")
    public List<Household> getAllHouseholds() {
        return householdService.getAllHouseholds();
    }

    @PostMapping("/households")
    public Household createHousehold(@RequestBody Household household) {
        return householdService.createHousehold(household);
    }

    @DeleteMapping("/households/{id}")
    public ResponseEntity<Void> deleteHousehold(@PathVariable Long id) {
        householdService.deleteHousehold(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/pets")
    public List<Pet> getAllPets() {
        return petService.getAllPets();
    }

    @PostMapping("/pets")
    public Pet createPet(@RequestBody Pet pet) {
        return petService.createPet(pet);
    }

    @DeleteMapping("/pets/{id}")
    public ResponseEntity<Void> deletePet(@PathVariable Long id) {
        petService.deletePet(id);
        return ResponseEntity.noContent().build();
    }
}
