package com.example.pethousehold.controller;

public class HouseholdController {
}
