// Test for REST Controller Layer
package com.example.pethousehold.controller;

import com.example.pethousehold.entity.Household;
import com.example.pethousehold.service.HouseholdService;
import com.example.pethousehold.service.PetService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Collections;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PetHouseholdController.class)
public class ControllerTests {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private HouseholdService householdService;

    @MockBean
    private PetService petService;

    @Test
    public void testGetAllHouseholds() throws Exception {
        when(householdService.getAllHouseholds()).thenReturn(Collections.emptyList());

        mockMvc.perform(get("/api/households"))
                .andExpect(status().isOk())
                .andExpect(content().json("[]"));
    }

    @Test
    public void testCreateHousehold() throws Exception {
        Household household = new Household();
        household.setName("Test Household");
        household.setEircode("D02X123");

        when(householdService.createHousehold(any(Household.class))).thenReturn(household);

        mockMvc.perform(post("/api/households")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"name\":\"Test Household\", \"eircode\":\"D02X123\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("Test Household"));
    }
}
