// GraphQL Query Resolver
package com.example.pethousehold.graphql;

import com.example.pethousehold.entity.Household;
import com.example.pethousehold.entity.Pet;
import com.example.pethousehold.service.HouseholdService;
import com.example.pethousehold.service.PetService;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import java.util.List;
import java.util.Optional;

@Controller
public class QueryResolver {

    private final HouseholdService householdService;
    private final PetService petService;

    public QueryResolver(HouseholdService householdService, PetService petService) {
        this.householdService = householdService;
        this.petService = petService;
    }

    @QueryMapping
    public List<Household> households() {
        return householdService.getAllHouseholds();
    }

    @QueryMapping
    public Optional<Household> householdById(Long id) {
        return householdService.getHouseholdById(id);
    }

    @QueryMapping
    public List<Pet> pets() {
        return petService.getAllPets();
    }

    @QueryMapping
    public Optional<Pet> petById(Long id) {
        return petService.getPetById(id);
    }
}
