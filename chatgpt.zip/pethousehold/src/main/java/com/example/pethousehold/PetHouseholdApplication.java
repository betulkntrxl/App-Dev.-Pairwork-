package com.example.pethousehold;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetHouseholdApplication {
	public static void main(String[] args) {
		SpringApplication.run(PetHouseholdApplication.class, args);
	}
}