// Test for Repository Layer
package com.example.pethousehold.repository;

import com.example.pethousehold.entity.Household;
import com.example.pethousehold.entity.Pet;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class RepositoryTests {

    @Autowired
    private HouseholdRepository householdRepository;

    @Autowired
    private PetRepository petRepository;

    @Test
    public void testSaveAndFindHousehold() {
        Household household = new Household();
        household.setName("Test Household");
        household.setEircode("D02X123");
        householdRepository.save(household);

        List<Household> households = householdRepository.findAll();
        assertThat(households).isNotEmpty();
    }

    @Test
    public void testSaveAndFindPet() {
        Pet pet = new Pet();
        pet.setName("Test Pet");
        pet.setType("Dog");
        petRepository.save(pet);

        List<Pet> pets = petRepository.findAll();
        assertThat(pets).isNotEmpty();
    }
}