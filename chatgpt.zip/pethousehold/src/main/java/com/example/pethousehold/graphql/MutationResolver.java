// GraphQL Mutation Resolver
package com.example.pethousehold.graphql;

import com.example.pethousehold.entity.Household;
import com.example.pethousehold.entity.Pet;
import com.example.pethousehold.service.HouseholdService;
import com.example.pethousehold.service.PetService;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;

@Controller
public class MutationResolver {

    private final HouseholdService householdService;
    private final PetService petService;

    public MutationResolver(HouseholdService householdService, PetService petService) {
        this.householdService = householdService;
        this.petService = petService;
    }

    @MutationMapping
    public Household createHousehold(Household household) {
        return householdService.createHousehold(household);
    }

    @MutationMapping
    public void deleteHousehold(Long id) {
        householdService.deleteHousehold(id);
    }

    @MutationMapping
    public Pet createPet(Pet pet) {
        return petService.createPet(pet);
    }

    @MutationMapping
    public void deletePet(Long id) {
        petService.deletePet(id);
    }
}
